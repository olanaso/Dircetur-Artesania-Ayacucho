//==============================
//     PALABRA CLAVE PARA TOKEN
//==============================
process.env.PALABRA_CLAVE= process.env.PALABRA_CLAVE ||'secret-sis-colegiados';

//==============================
//   TIEMPO DE CADUCIDAD TOKEN
//==============================
process.env.CADUCIDAD_TOKEN= '24h';

//==============================
//          PORT SERVER
//==============================
process.env.PORT = process.env.PORT || 3000;
//==============================