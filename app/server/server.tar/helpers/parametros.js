module.exports = {
    CONCEPTOINGRESO:{
        CERTIFICADO:1,
        APORTES:2,
        MULTA:3,
          CERTIFICADO_PROMO:4
    },
    ESTADOAPORTES:{
        PENDIENTE:1,
        PAGADO:2,
        CANCELADO:3
    },
    ESTADOAPROBADO:{
        PENDIENTE:1,
        APROBADO:2,
        RECHAZADO:3
    },
     ESTADOTRANSACCION:{
        ANULADO:1,
        NOANULADO:0
     
    }
};